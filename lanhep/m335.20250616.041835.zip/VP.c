#include <math.h>
#include <complex.h>
#include <stdio.h>
#include "VP.h"

double FF(double id, double v0,double a0,double v1,double a1,double v2,double a2,
	       double Mv,  double m0, double m1, double m2, double mu){


  double Mv2,m02,m22,m12,mu2;
  double VPPP,VPMM,VMPM,VMMP,APPP,APMM,AMPM,AMMP;
  double C0,C1,C12,C112,C001,C00,DeltaC1;

  // combinations of vector and axial coupling constants
  VPPP=(v0*v2*v1+v0*a2*a1+a0*v2*a1+a0*a2*v1)/M_PI/M_PI;
  VPMM=(v0*v2*v1+v0*a2*a1-a0*v2*a1-a0*a2*v1)/M_PI/M_PI;
  VMPM=(v0*v2*v1-v0*a2*a1+a0*v2*a1-a0*a2*v1)/M_PI/M_PI;
  VMMP=(v0*v2*v1-v0*a2*a1-a0*v2*a1+a0*a2*v1)/M_PI/M_PI;
 
  APPP=(a0*a2*a1+a0*v2*v1+v0*a2*v1+v0*v2*a1)/M_PI/M_PI;
  APMM=(a0*a2*a1+a0*v2*v1-v0*a2*v1-v0*v2*a1)/M_PI/M_PI;
  AMPM=(a0*a2*a1-a0*v2*v1+v0*a2*v1-v0*v2*a1)/M_PI/M_PI;
  AMMP=(a0*a2*a1-a0*v2*v1-v0*a2*v1+v0*v2*a1)/M_PI/M_PI;


  // printf("vector %f %f %f %f \n",VPPP,VPMM,VMPM,VMMP);
  //printf("axial  %f %f %f %f \n",APPP,APMM,AMPM,AMMP);

  // squares of masses
  Mv2=Mv*Mv;
  m02=m0*m0;
  m22=m2*m2;
  m12=m1*m1;
  mu2=mu*mu;

  // The quantities C0,C1,C12,C112,C001 are the averages over the
  // mass assignments m0,m1,m2 and m0,m2,m1
  // Use real parts only
  C0=(creal(VP_C0(Mv,m0,m1,m2))+creal(VP_C0(Mv,m0,m2,m1)))/2;
  C1=(creal(VP_C1(Mv,m0,m1,m2))+creal(VP_C1(Mv,m0,m2,m1)))/2;
  C12=(creal(VP_C12(Mv,m0,m1,m2))+creal(VP_C12(Mv,m0,m2,m1)))/2;
  C112=(creal(VP_C112(Mv,m0,m1,m2))+creal(VP_C112(Mv,m0,m2,m1)))/2;
  C001=(creal(VP_C001(Mv,m0,m1,m2,mu))+creal(VP_C001(Mv,m0,m2,m1,mu)))/2;
  C00=(creal(VP_C00(Mv,m0,m1,m2,mu))+creal(VP_C00(Mv,m0,m2,m1,mu)))/2;
  DeltaC1=(creal(VP_C1(Mv,m0,m1,m2))-creal(VP_C1(Mv,m0,m2,m1)))/2;

if ((int) id == 1){
  double f1 =   1.0/4*VPPP - 1.0/4*(m12-m22)*VPPP*DeltaC1 + 1.0/4*C0*m0*m1*VMMP + 1.0/4*C0*m2*m0*VMPM;
  f1 += - 1.0/4*C1*(m12+m22)*VPPP + 1.0/2*C1*m0*m1*VMMP - 1.0/2*C1*m2*m1*VPMM + 1.0/2*C1*m2*m0*VMPM + 2*C001*VPPP;
  return -f1;
  }
else if ((int) id ==2){
  double f2 = - C12*Mv2*VPPP - 2*C112*Mv2*VPPP;
  return -f2;
  }
else if ((int) id ==3){
  double f3 =  - 1.0/2*VPPP + 1.0/4*(m12-m22)*VPPP*DeltaC1 + 1.0/2*m0*m1*VMMP*DeltaC1 - 1.0/2*m2*m0*VMPM*DeltaC1;
  f3 += - 1.0/4*C0*m0*m1*VMMP - 1.0/2*C0*m02*VPPP - 1.0/4*C0*m2*m0*VMPM + 1.0/4*C1*(m12+m22)*VPPP;
  f3 += - C1*m02*VPPP + 1.0/2*C1*m2*m1*VPMM + 2*C00*VPPP + 2*C001*VPPP;
  return -f3;
  }
else if ((int) id ==5){
  double f5 =  - 1.0/4*(m12-m22)*APPP*DeltaC1 - 1.0/4*C0*m0*m1*AMMP - 1.0/4*C0*m2*m0*AMPM;
  f5 += - 1.0/4*C1*(m12+m22)*APPP - 1.0/2*C1*m0*m1*AMMP - 1.0/2*C1*m2*m1*APMM - 1.0/2*C1*m2*m0*AMPM;
  return -f5;
  }
else if ((int) id ==8){
  double f8 =  1.0/2*C12*Mv2*APPP;
  return -f8;
  }
else
  return 0;
		 
}
