
/* ###############################################################################
## This module calculates the Veltman-Passarino functions for 1-point 2-point and
## 3-point Feynman integtrals with up to cubic power in loop momentum in numerator.
## they are all calulated in the q^2=0 limit.
## The arguments are the external invariant momenta Mv,Mv and internal masses
## m0,m1,m2 (NOT their squares)
## For theb UV divergent integrals B0,B1,C00,C001,C002, the subtraction scale mu
## must be specified
## The denomnators of the Feynman propagators are
##  (k^2-m_0^2), ((k+p_1)^2-m_1^2) and ((k+p_2)^-m_2^2)
##  The Veltman Passarino function names all have the prefix VP_
  ##########################################################################*/



#include <math.h>
#include <complex.h>    //standard complex number library


double complex f(double,double);
double complex CIntegral(double, double, double, int);
double complex  LogIntegral(double, double, double, double, int);
double complex OmegaCIntegral(double, double, double, double, int, int);
double complex OmegaLogIntegral(double,double, double, double, double,int, int);
double VP_A0(double, double);
double  VP_B0(double, double, double);
double  VP_B1(double, double, double);
double complex VP_B0tilde(double, double, double, double);
double complex VP_B1tilde(double, double, double, double);
double complex VP_C0(double,double,double,double);
double complex VP_C1(double,double,double,double);
double complex VP_C2(double,double,double,double);
double complex VP_C11(double,double,double,double);
double complex VP_C22(double,double,double,double);
double complex VP_C12(double,double,double,double);
double complex VP_C00(double,double,double,double,double);
double complex  VP_C111(double, double,double, double);
double complex  VP_C222(double, double,double, double);
double complex  VP_C112(double, double,double, double);
double complex  VP_C122(double, double,double, double);
double complex  VP_C001(double, double,double, double, double);
double complex  VP_C002(double, double,double, double, double);

///////////////////////////////////////////////////////////////////////


/*###################################################################################
#  f(x,y) = int_0^1 dro/(ro^2+x*ro*y)
# define the function f(x,y) , x=-(Mv2+m12-m22)/Mv2, y=m1^2/Mv2
##  lambd = sqrt(Mv^4+m1^4+m2^4-2m1*2 m2^2 -2 m1^2 Mv^2 -2 m2^2 Mv^2)  above threshold
##  lambd = sqrt(-Mv^4-m1^4-m2^4+2m1*2 m2^2 +2 m1^2 Mv^2 +2 m2^2 Mv^2) below threshold
## above threshold it is the magnitude of the 3-momentum of one particle decaying into
## the 2 others from rest
###################################################################################*/

double complex f(double x, double y){
  double ref,imf,lambd,theta;
  if (y > x*x/4){ // complex roots
    imf=0;
    lambd=sqrt(4*y-x*x);
     if (x == - 2*y){  // find correct branch of atan, 0 < theta < pi
      theta=M_PI;
    }
     else{
    theta=atan(lambd/(2*y+x));
    }
     if(theta < 0) {
       theta+=M_PI;
     }
    ref=2/lambd*theta;
  }
  else{  // real roots
    lambd=sqrt(x*x-4*y);
    if (lambd==0){  
      ref=2/(2*y+x);
      imf=0;
     }
    else { // lambda not zero
    //  use abs to select real part above threshold   
    ref=1/lambd*log(fabs(2*y+x+lambd)/(fabs(2*y+x-lambd)));
    if (lambd > 2*y+x || lambd < -2*y-x) {  //  no cut
      imf=0;
      }
    else if (lambd < 2*y+x && lambd > -2*y-x){ //  cut
      imf=2*M_PI/lambd;
    }
       } 
  } // end of real roots
  return ref+imf*I;
    }


/*################################################################
## CIntegral  is the integral over ro with integrand
##  -Mv2 ro^n/(Mv2*ro*(1-ro)+(m12-m02)*ro+m02)
##  they obey the recursion relation )(for n > 1)
##  CIntegral(n)=1/(n-1)+(Mv2+m02-m12)/Mv2*CIntegral(n-1)
##    - m02/Mv2*CIntegral(n-2)
################################################################*/
double complex CIntegral(double Mv2, double m02, double m12, int n){
  double complex Cint;
  double x,y,lmg;
  x=-(Mv2+m02-m12)/Mv2;
  y=m02/Mv2;
  lmg=log(m12/m02);
 
  if (n==0) {
	   Cint=f(x,y);
    } 
  else if  (n==1) {
	       Cint=(lmg-f(x,y)*x)/2;
    }
  else{
    Cint=1.0/(n-1)-x*CIntegral(Mv2,m02,m12,(n-1))-y*CIntegral(Mv2,m02,m12,(n-2));
  }
    return Cint;
}
//#######################################################################


/*#########################################################################################
##  LogIntegral integrates ro^n log(-(Mv^2*ro*(1-ro)+m2^2*ro+m1^2*(1-ro))/mu^2)
##   over ro  in terms of CIntegral (integration by parts)
######################################################################################*/
 double complex  LogIntegral(double Mv2,double m02, double m12,double mu2,int n){
  double x,y,lmg;
  double complex LogInt;
  x=-(Mv2+m02-m12)/Mv2;
  y=m02/Mv2;
  lmg=-log(m12/mu2); 
  LogInt = lmg-2*CIntegral(Mv2,m02,m12,n+2)-x*CIntegral(Mv2,m02,m12,n+1);
   LogInt *= 1.0/(n+1);
   return LogInt ;
}
/*############################################################################  */


/*###############################################################################
## OmegaCIntegral(l,n) is the integral over omega with integrand
##  Mv2* ro^l omega^n /(Mv2*ro*(1-ro)+((m22*1-omega)+m32*omega-m12)*ro+m12)
##   in terms of the integrals LogIntegral 
##  The recursion relation is
## OmegaCIntegral(l,n)= Mv2/(m32-m22)*(1/l/n-OmegaCIntegral(l+1,n-1)+
## (Mv2+m12-m22)/Mv2*Omega(l,n-1)-m12/Mv2*OmegaCIntegral(l-1.n-1)
###########################################################################*/
 double complex OmegaCIntegral(double Mv2,double m02,double m12,double m22,int l,int n){
   double x1,x2,y,mu2;
  double complex OmegaCInt; 
  mu2=Mv2;  // mu2 cancels so set it arbitrarily
  y=m02/Mv2;
  x1=-(Mv2+m02-m12)/Mv2;
  x2=-(Mv2+m02-m22)/Mv2;
 
  if (n==0) {
        OmegaCInt = LogIntegral(Mv2,m02,m12,mu2,l-1)-LogIntegral(Mv2,m02,m22,mu2,l-1);
    }
  else{
       OmegaCInt =   1.0/l/n-OmegaCIntegral(Mv2,m02,m12,m22,l+1,n-1) ;
       OmegaCInt +=  -x2*OmegaCIntegral(Mv2,m02,m12,m22,l,n-1) ;
       OmegaCInt +=  -y*OmegaCIntegral(Mv2,m02,m12,m22,l-1,n-1);
     }
  OmegaCInt *= 1.0/(x1-x2);
  return OmegaCInt;
 }
  /*######## ###################################################################*/

/*##############################################################################
## OmegaLogIntegral(l,n) expresses the integral
## ro^l omega^n log(-(Mv2*ro*(1-ro)+((m22*1-omega)+m32*omega-m12)*ro+m12)/mu2)
## in terms of OmegaCIntegral(l',n') and LogIntegral using integration by parts
## over omega
#############################################################################*/
double complex OmegaLogIntegral(double Mv2,double m02,double m12, double m22,double mu2,int l,int n){
  double y,x1,x2;
  double complex OmegaLInt;
  y=m02/Mv2;
  x1=-(Mv2+m02-m12)/Mv2;
  x2=-(Mv2+m02-m22)/Mv2;
  OmegaLInt  =  LogIntegral(Mv2,m02,m12,mu2,l);
  OmegaLInt +=  (x2-x1)*OmegaCIntegral(Mv2,m02,m12,m22,l+1,n+1);
  OmegaLInt *=  1.0/(n+1);
  return OmegaLInt;
   }
/*###########################################################################*/


//####  function A0
double VP_A0(double m, double mu){
  double  A;
  A=m*m*(1-2*log(m/mu));
  return A;
   }  
//#################################

//#### 2 point integral (bubbles)  B_{}
//#  function B0(m2,m3,0)
double  VP_B0(double m1,double m2,double mu){
  double m12,m22,mu2;
  double B;
  m12=m1*m1;
  m22=m2*m2;
  mu2=mu*mu;
  if (m2==m1){
    B=log(m12/mu2);
  }
    else {
      B=1.0-log(m12/mu2)/2.0-log(m22/mu2)/2.0
	-(m22+m12)/2.0/(m12-m22)*log(m12/m22);
    }   
  return B;
   } 
/*#################################################################################*/

//### function B0tilde
// function B0(Mv,m1,m2)

double complex  VP_B0tilde(double Mv, double m1, double m2, double mu){
  double Mv2,m12,m22,mu2,x,y,LG,LMV;
  double complex FF,B0;
  Mv2=Mv*Mv;
  m12=m1*m1;
  m22=m2*m2;
  mu2=mu*mu;
  x=-(Mv2+m12-m22)/Mv2;
  y=m12/Mv2;
  FF=f(x,y);
  LG=log(m22/m12);
  LMV=log(m22/mu2);
  B0 = -(FF * ( 2*y - 1.0/2.0*pow(x,2)) + LG * ( 1.0/2.0*x )- 2 + LMV);
  return B0;
   }
//###########################################################################

//### function B1tilde
//# function B1(Mv,m1,m2)
double complex  VP_B1tilde(double Mv, double m1, double m2, double mu){
  double Mv2,m12,m22,mu2;
  double complex B1t;
  m12=m1*m1;
  Mv2=Mv*Mv;
  m22=m2*m2;
  mu2=mu*mu;
  B1t= VP_A0(m2,mu)- VP_A0(m1,mu);
  B1t += (Mv2+m12-m22)* VP_B0tilde(Mv,m1,m2,mu);
  B1t *= -1.0/2/Mv2;
  return B1t;
}
//#########################################################################

//### function B1
double  VP_B1(double m1,double m2, double mu){
  double m12,m22,mu2,a1,b1;
  m12=m1*m1;
  m22=m2*m2;
  mu2=mu*mu;
  if (m2==m1){
    b1=log(m22/mu2)/2;
  }
  else{ 
    a1 =  - 1.0/4.0*m22*m22 + m12*m22 - 3.0/4.0*m12*m12 ;
    a1 +=  1.0/2.0*log(m12/mu2)* m12*m12 + 1.0/2.0*log(m22/mu2)*m22*m22;
    a1 +=  -log(m22/mu2)*m12*m22;
    b1 = a1/(m12-m22)/(m12-m22);
    }
    return b1;
    }
//#######################################################################

//## 3 point functions (triangles) C_{}

/*######################################################################
## The C_{} functions can be  expressed in terms of OmegaCIntegral
##  and/or OmegaLogIntegral for m2 < > m3
##  or in terms of CIntegral anmd/or LogIntegral for m2 = m3
### C2,C22,C002,C122,C222 are obtained from C1,C11, C111,C112
##    by ex[ploiting the symmetry of the Feynman integrals under
##     p1 <-> p2,  m2 <-> m3
#####################################################################*/

//## function C0
double complex VP_C0(double Mv,double m0,double m1,double m2){
  double complex C0;
  double Mv2,m02,m12,m22;
    Mv2=Mv*Mv;
  m02=m0*m0;
  m12=m1*m1;
  m22=m2*m2;

  if (m2 == m1){
    C0=-CIntegral(Mv2,m02,m22,1)/Mv2;
}
 else{
   C0=-OmegaCIntegral(Mv2,m02,m12,m22,1,0)/Mv2;
}
  return C0;
 }
//#############################################

//## function C1
double complex VP_C1(double Mv,double m0,double m1,double m2){
  double complex C1;
  double Mv2,m02,m12,m22;
  Mv2=Mv*Mv;
  m02=m0*m0;
  m12=m1*m1;
  m22=m2*m2;
 
  if (m2 == m1){
    C1 = CIntegral(Mv2,m02,m22,2)/2/Mv2;
  }
  else{
   C1 = OmegaCIntegral(Mv2,m02,m12,m22,2,1)/Mv2;
  }
  return C1;
   }
//#############################################

//## function C2  (exploits symmetry under p1 <-> -p2, m1 <-> m2)
double complex VP_C2(double Mv,double m0,double m1,double m2){
  double complex C2;
  C2 = VP_C1(Mv,m0,m2,m1);
  return C2;
}
//############################################


//## function C11
double complex VP_C11(double Mv,double m0,double m1, double m2){
  double complex C11;
  double Mv2,m02,m12,m22;
  Mv2=Mv*Mv;
  m02=m0*m0;
  m12=m1*m1;
  m22=m2*m2;
  if (m2 == m1){
    C11 = -CIntegral(Mv2,m02,m22,3)/3/Mv2;
  }
  else{
    C11 = -OmegaCIntegral(Mv2,m02,m12,m22,3,2)/Mv2;
  }
  return C11;
   }
//#############################################

//## function C22  (exploits symmetry under p1 <-> -p2, m1 <-> m2)
double complex VP_C22(double Mv,double m0,double m1, double m2){
  double complex C22;
  C22 = VP_C11(Mv,m0,m2,m1);
   return C22;
}
//############################################


//## function C12
double  complex  VP_C12(double Mv,double m0,double m1,double m2){
  double complex C12;
double m02,m12,m22,Mv2;
Mv2=Mv*Mv;
m02=m0*m0;
m12=m1*m1;
m22=m2*m2;
  if (m2 == m1){
		C12=-CIntegral(Mv2,m02,m22,3)/6/Mv2;
  }
  else{
       C12 =  -OmegaCIntegral(Mv2,m02,m12,m22,3,1)/Mv2;
       C12 +=  OmegaCIntegral(Mv2,m02,m12,m22,3,2)/Mv2;
  }
return C12;
}
    //######################################################


//## function C00
double complex  VP_C00(double Mv, double m0, double m1, double m2, double mu){
  double complex C00;
  double Mv2,m02,m12,m22,mu2;
    Mv2=Mv*Mv;
  m12=m1*m1;
  m22=m2*m2;
  m02=m0*m0;
  mu2=mu*mu;
  if (m2 == m1){
    C00 =  -LogIntegral(Mv2,m02,m22,mu2,1)/2;
  }
  else{
    C00 =  -OmegaLogIntegral(Mv2,m02,m12,m22,mu2,1,0)/2;
  }
  return C00;
}
    //###################################################### 

//## function C111
double complex  VP_C111(double Mv, double m0,double m1, double m2){
  double complex C111;
  double Mv2,m02,m12,m22;
  Mv2=Mv*Mv;
  m12=m1*m1;
  m22=m2*m2;
  m02=m0*m0;
   if (m2 == m1){
	 C111 = CIntegral(Mv2,m02,m22,4)/4/Mv2;
   }
   else{
	C111 = OmegaCIntegral(Mv2,m02,m12,m22,4,3)/Mv2;
   }
 return C111;
}
    //#################################################################


    //## function C222  (exploits symmetry under p1 <-> -p2, m1 <-> m2)
double complex VP_C222(double Mv,double m0, double m1, double m2){
   double complex C222;
   C222 = VP_C111(Mv,m0,m2,m1);
   return C222;
}
    //##################################################################

    
//## function C112
double complex  VP_C112(double Mv,double m0,double m1,double m2){
  double complex C112;
  double Mv2,m02,m12,m22;
  Mv2=Mv*Mv;
  m12=m1*m1;
  m22=m2*m2;
  m02=m0*m0;
  if (m2 == m1){
    C112 = CIntegral(Mv2,m02,m22,4)/12/Mv2;
  }
  else{
    C112 =   OmegaCIntegral(Mv2,m02,m12,m22,4,2)/Mv2;
    C112 += -OmegaCIntegral(Mv2,m02,m12,m22,4,3)/Mv2;
  }
    return C112;
}
//##############################################################

    
//## function C122  (exploits symmetry under p1 <-> -p2, m2 <-> m3)
double complex VP_C122(double Mv,double m0,double m1,double m2){
  double complex C122;
  C122 = VP_C112(Mv,m0,m2,m1);
  return C122;
}
//###############################################################



//## function C001
double complex VP_C001(double Mv, double m0, double m1, double m2, double mu){
  double complex C001;
  double Mv2, m02,m12,m22,mu2;
  Mv2=Mv*Mv;
  m12=m1*m1;
  m22=m2*m2;
  m02=m0*m0;
  mu2=mu*mu;
  if (m2 == m1){
    C001 =  LogIntegral(Mv2,m02,m22,mu2,2)/4;
  }
  else{
    C001 =  OmegaLogIntegral(Mv2,m02,m12,m22,mu2,2,1)/2;
  }
  return C001;
}
//#################################################################

//## function C002  (exploits symmetry under p1 <-> -p2, m1 <-> m2)
double complex  VP_C002(double Mv,double m0, double m1, double m2, double mu){
  double complex C002;
  C002 = VP_C001(Mv,m0,m2,m1,mu);
  return C002;
}
//#################################################################*/
