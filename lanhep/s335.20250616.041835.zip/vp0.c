#include <math.h>
#include <complex.h>
#include <stdio.h>

//#include "VP.h"

//	My new lines started here

// 	B0 is defined here
    
   double Kallen(double m12, double m22, double MV2){
   double res;
   double lambda = MV2*MV2 + m12*m12 + m22*m22 - 2*m12*m22 - 2*m12*MV2 - 2*m22*MV2;
    	if(lambda>=0){
    		res = lambda;
    	}
    	else{
    		res = -lambda;
    	}
    	return res;
    }
    
    double DiscB(double MV2, double m1, double m2){
	double complex f( double,double);
    	double res;
    	double m12 = pow(m1,2), m22 = pow(m2,2);
    	double lambda = MV2*MV2 + m12*m12 + m22*m22 - 2*m12*m22 - 2*m12*MV2 - 2*m22*MV2;
	double x = (m22 - m12 - MV2)/MV2, y = m12/MV2;   

    		res = lambda/(2*pow(MV2,2))*creal(f(x,y));
    	return	res;
    }
    
    double A00(double m, double Mu){
    	double res=0;
    
    	res = (3*pow(m,4))/8. + (pow(m,4)*log(pow(Mu,2)/pow(m,2)))/4.;
  	return res;
    };
    
    
    
    double B0(double MV, double m2, double m3, double Mu){
    	double res=0;
    	double MV2 = MV*MV;
    	double m22 = m2*m2;
    	double m32 = m3*m3;
    	double Mu2 = Mu*Mu;
    
    if(m2==m3){
    	res=2 + DiscB(MV2,m2,m2) + log(Mu2/m22);
    }
    
    else{
    	res= 2 + DiscB(MV2,m2,m3) - ((m22 - m32 + MV2)*log(m22/m32))/(2.*MV2) + log(Mu2/m32);
    }
  	return res;
    };
   
    double B00(double MV, double m2, double m3, double Mu){
    	double res=0;
    	double MV2 = MV*MV;
    	double m22 = m2*m2;
    	double m32 = m3*m3;
    	double Mu2 = Mu*Mu;
    	
    	
    
    if(m2==m3){
    	res=(21*pow(m2,2) - 4*pow(MV,2))/18. + ((4*pow(m2,2) - pow(MV,2))*DiscB(pow(MV,2),m2,m2))/12. + ((6*pow(m2,2) - pow(MV,2))*log(pow(Mu,2)/pow(m2,2)))/12.;
    }
    
    else{
    	res= -(3*pow(m2,4) - 6*pow(m2,2)*pow(m3,2) + 3*pow(m3,4) - 21*pow(m2,2)*pow(MV,2) - 21*pow(m3,2)*pow(MV,2) + 8*pow(MV,4))/(36.*pow(MV,2)) - ((pow(m2,4) - 2*pow(m2,2)*pow(m3,2) + pow(m3,4) - 2*pow(m2,2)*pow(MV,2) - 2*pow(m3,2)*pow(MV,2) + pow(MV,4))*DiscB(pow(MV,2),m2,m3))/(12.*pow(MV,2)) + ((pow(m2,6) - 3*pow(m2,4)*pow(m3,2) + 3*pow(m2,2)*pow(m3,4) - pow(m3,6) - 3*pow(m2,4)*pow(MV,2) + 3*pow(m3,4)*pow(MV,2) - 3*pow(m2,2)*pow(MV,4) - 3*pow(m3,2)*pow(MV,4) + pow(MV,6))*log(pow(m2,2)/pow(m3,2)))/(24.*pow(MV,4)) + ((3*pow(m2,2) + 3*pow(m3,2) - pow(MV,2))*log(pow(Mu,2)/pow(m3,2)))/12.;
    }
  	return res;
    };

   
    double pivp(double gd, double MV, double Mt, double MtD, double Mtp, double MHD, double Mu){
    	double VP_A0(double m, double mu);
    	double res=0;
    	double MH = 125.5;
    	double D1=0,D2=0,D3=0,D4=0,D5=0,D6=0,D7=0,D8=0,D9=0;
    	double gd2 = gd*gd, gd4 = gd2*gd2;
    	double MV2 = MV*MV;
    	double Mt2 = Mt*Mt, Mt4 = Mt2*Mt2;
    	double MtD2 = MtD*MtD;
    	double Mtp2 = Mtp*Mtp, Mtp4 = Mtp2*Mtp2;
    	double MHD2 = MHD*MHD, MHD4 = MHD2*MHD2;
    	double Mu2 = Mu*Mu;
    	double PI2 = M_PI*M_PI;
    	double SintR=sqrt((Mtp2 - MtD2)/(Mtp2 - Mt2)),SintL=Mt/MtD*SintR;
    	double CostR=sqrt(1-pow(SintR,2)), CostL=sqrt(1-pow(SintL,2));
    	
    	double SinT=0,CosT=1;
    	double SinT2= SinT*SinT, CosT2=CosT*CosT;
    	
    	double SintR2 = SintR*SintR, SintR4 = SintR2*SintR2;
    	double SintL2 = SintL*SintL, SintL4 = SintL2*SintL2;
    	double CostR2 = CostR*CostR, CostR4 = CostR2*CostR2;
    	double CostL2 = CostL*CostL, CostL4 = CostL2*CostL2;
    	
    	double vd = 2*MV/gd, vd2 =vd*vd;
    	
    	double tL = atan(SintL/CostL), tR = atan(SintR/CostR);
    
    	D1 = -gd2*SinT2*VP_A0(MH,Mu)/(64.*PI2);
    	
    	D2 = -gd2*CosT2*VP_A0(MHD,Mu)/(64.*PI2);
    	
    	D3 = -gd2*VP_A0(MV,Mu)/(8.*PI2) -gd2*A00(MV,Mu)/(16.*PI2*MV2);
    	
    	D4 = -gd2*VP_A0(MV,Mu)/(8.*PI2) -gd2*A00(MV,Mu)/(16.*PI2*MV2);
    	
    	D5 = gd2*Mt2*SintL2*B0(MV,Mt,MtD,Mu)/(32.*PI2) + gd2*MtD2*SintL2*B0(MV,Mt,MtD,Mu)/(32.*PI2) - gd2*MV2*SintL2*B0(MV,Mt,MtD,Mu)/(32.*PI2) - gd2*Mt*MtD*SintL*SintR*B0(MV,Mt,MtD,Mu)/(8.*PI2) + gd2*Mt2*SintR2*B0(MV,Mt,MtD,Mu)/(32.*PI2) + gd2*MtD2*SintR2*B0(MV,Mt,MtD,Mu)/(32.*PI2) - gd2*MV2*SintR2*B0(MV,Mt,MtD,Mu)/(32.*PI2) - gd2*SintL2*B00(MV,Mt,MtD,Mu)/(8.*PI2) - gd2*SintR2*B00(MV,Mt,MtD,Mu)/(8.*PI2) + gd2*SintL2*VP_A0(Mt,Mu)/(32.*PI2) + gd2*SintL2*VP_A0(MtD,Mu)/(32.*PI2) + gd2*SintR2*VP_A0(Mt,Mu)/(32.*PI2) + gd2*SintR2*VP_A0(MtD,Mu)/(32.*PI2);
    	
    	D6 = gd2*MtD2*CostL2*B0(MV,MtD,Mtp,Mu)/(32.*PI2) + gd2*Mtp2*CostL2*B0(MV,MtD,Mtp,Mu)/(32.*PI2) - gd2*MV2*CostL2*B0(MV,MtD,Mtp,Mu)/(32.*PI2) - gd2*Mtp*MtD*CostL*CostR*B0(MV,MtD,Mtp,Mu)/(8.*PI2) + gd2*MtD2*CostR2*B0(MV,MtD,Mtp,Mu)/(32.*PI2) + gd2*Mtp2*CostR2*B0(MV,MtD,Mtp,Mu)/(32.*PI2) - gd2*MV2*CostR2*B0(MV,MtD,Mtp,Mu)/(32.*PI2) - gd2*CostL2*B00(MV,MtD,Mtp,Mu)/(8.*PI2) - gd2*CostR2*B00(MV,MtD,Mtp,Mu)/(8.*PI2) + gd2*CostL2*VP_A0(Mtp,Mu)/(32.*PI2) + gd2*CostL2*VP_A0(MtD,Mu)/(32.*PI2) + gd2*CostR2*VP_A0(Mtp,Mu)/(32.*PI2) + gd2*CostR2*VP_A0(MtD,Mu)/(32.*PI2);
    	
    	D7 = gd4*SinT2*vd2*B00(MV,MH,MV,Mu)/(64.*PI2*MV2) - gd4*SinT2*vd2*B0(MV,MH,MV,Mu)/(64.*PI2);
    	
    	D8 = gd4*CosT2*vd2*B00(MV,MHD,MV,Mu)/(64.*PI2*MV2) - gd4*CosT2*vd2*B0(MV,MHD,MV,Mu)/(64.*PI2);
    	
    	D9 = 3*gd2*MV2*B0(MV,MV,MV,Mu)/(8.*PI2) + 9*gd2*B00(MV,MV,MV,Mu)/(16.*PI2) + gd2*A00(MV,Mu)/(8.*PI2*MV2);
  /*  	
   	printf("\npivpD1=%e\n",D1);
    	printf("pivpD2=%e\n",D2);
    	printf("pivpD3=%e\n",D3);
    	printf("pivpD4=%e\n",D4);
    	printf("pivpD5=%e\n",D5);
    	printf("pivpD6=%e\n",D6);
    	printf("pivpD7=%e\n",D7);
    	printf("pivpD8=%e\n",D8);
    	printf("pivpD9=%e\n",D9);
  */  	
      return D1+D2+D3+D4+3*D5+3*D6+D7+D8+D9;
    
    }

   
    double piv0(double gd, double MV, double Mt, double MtD, double Mtp, double MHD, double Mu){
    	double VP_A0(double m, double mu);
    	double res=0;
    	double MH = 125.5;
    	double D1=0,D2=0,D3=0,D4=0,D5=0,D6=0,D7=0,D8=0,D9=0,D10=0,D11=0;
    	double gd2 = gd*gd, gd4 = gd2*gd2;
    	double MV2 = MV*MV;
    	double Mt2 = Mt*Mt, Mt4 = Mt2*Mt2;
    	double MtD2 = MtD*MtD;
    	double Mtp2 = Mtp*Mtp, Mtp4 = Mtp2*Mtp2;
    	double MHD2 = MHD*MHD, MHD4 = MHD2*MHD2;
    	double Mu2 = Mu*Mu;
    	double PI2 = M_PI*M_PI;
    	double SintR=sqrt((Mtp2 - MtD2)/(Mtp2 - Mt2)),SintL=Mt/MtD*SintR;
    	double CostR=sqrt(1-pow(SintR,2)), CostL=sqrt(1-pow(SintL,2));
    	
    	double SinT=0,CosT=1;
    	double SinT2= SinT*SinT, CosT2=CosT*CosT;
    	
    	double SintR2 = SintR*SintR, SintR4 = SintR2*SintR2;
    	double SintL2 = SintL*SintL, SintL4 = SintL2*SintL2;
    	double CostR2 = CostR*CostR, CostR4 = CostR2*CostR2;
    	double CostL2 = CostL*CostL, CostL4 = CostL2*CostL2;
    	
    	double vd = 2*MV/gd, vd2 =vd*vd;
    	
    	double tL = atan(SintL/CostL), tR = atan(SintR/CostR);
    
    	D1 = -gd2*SinT2*VP_A0(MH,Mu)/(64.*PI2);
    	
    	D2 = -gd2*CosT2*VP_A0(MHD,Mu)/(64.*PI2);
    	
    	D3 = -gd2*A00(MV,Mu)/(8*PI2*MV2) - gd2*VP_A0(MV,Mu)/(4*PI2);
    	
    	D4 = -gd2*Mt2*SintL2*SintR2*B0(MV,Mt,Mt,Mu)/(16.*PI2) + gd2*Mt2*SintL4*B0(MV,Mt,Mt,Mu)/(32.*PI2) + gd2*Mt2*SintR4*B0(MV,Mt,Mt,Mu)/(32.*PI2) - gd2*SintL4*B00(MV,Mt,Mt,Mu)/(16.*PI2) - gd2*MV2*SintL4*B0(MV,Mt,Mt,Mu)/(64.*PI2) - gd2*SintR4*B00(MV,Mt,Mt,Mu)/(16.*PI2) - gd2*MV2*SintR4*B0(MV,Mt,Mt,Mu)/(64.*PI2) + gd2*SintL4*VP_A0(Mt,Mu)/(32.*PI2) + gd2*SintR4*VP_A0(Mt,Mu)/(32.*PI2);
    	
    	D5 = -gd2*B00(MV,MtD,MtD,Mu)/(8.*PI2) - gd2*MV2*B0(MV,MtD,MtD,Mu)/(32.*PI2) + gd2*VP_A0(MtD,Mu)/(16.*PI2) ;
    	
    	D6 = gd2*Mt2*SintL2*CostL2*B0(MV,Mt,Mtp,Mu)/(64.*PI2) + gd2*Mtp2*SintL2*CostL2*B0(MV,Mt,Mtp,Mu)/(64.*PI2) - gd2*SintL2*CostL2*B00(MV,Mt,Mtp,Mu)/(16.*PI2) - gd2*MV2*SintL2*CostL2*B0(MV,Mt,Mtp,Mu)/(64.*PI2) - gd2*Mt*Mtp*SintL*SintR*CostL*CostR*B0(MV,Mt,Mtp,Mu)/(16.*PI2) + gd2*Mt2*SintR2*CostR2*B0(MV,Mt,Mtp,Mu)/(64.*PI2) + gd2*Mtp2*SintR2*CostR2*B0(MV,Mt,Mtp,Mu)/(64.*PI2) - gd2*SintR2*CostR2*B00(MV,Mt,Mtp,Mu)/(16.*PI2) - gd2*MV2*SintR2*CostR2*B0(MV,Mt,Mtp,Mu)/(64.*PI2) + gd2*SintL2*CostL2*VP_A0(Mt,Mu)/(64.*PI2) + gd2*SintL2*CostL2*VP_A0(Mtp,Mu)/(64.*PI2) + gd2*SintR2*CostR2*VP_A0(Mt,Mu)/(64.*PI2) + gd2*SintR2*CostR2*VP_A0(Mtp,Mu)/(64.*PI2);
    	
    	D7 = gd2*Mt2*SintL2*CostL2*B0(MV,Mtp,Mt,Mu)/(64.*PI2) + gd2*Mtp2*SintL2*CostL2*B0(MV,Mtp,Mt,Mu)/(64.*PI2) - gd2*SintL2*CostL2*B00(MV,Mtp,Mt,Mu)/(16.*PI2) - gd2*MV2*SintL2*CostL2*B0(MV,Mtp,Mt,Mu)/(64.*PI2) - gd2*Mt*Mtp*SintL*SintR*CostL*CostR*B0(MV,Mtp,Mt,Mu)/(16.*PI2) + gd2*Mt2*SintR2*CostR2*B0(MV,Mtp,Mt,Mu)/(64.*PI2) + gd2*Mtp2*SintR2*CostR2*B0(MV,Mtp,Mt,Mu)/(64.*PI2) - gd2*SintR2*CostR2*B00(MV,Mtp,Mt,Mu)/(16.*PI2) - gd2*MV2*SintR2*CostR2*B0(MV,Mtp,Mt,Mu)/(64.*PI2) + gd2*SintL2*CostL2*VP_A0(Mt,Mu)/(64.*PI2) + gd2*SintL2*CostL2*VP_A0(Mtp,Mu)/(64.*PI2) + gd2*SintR2*CostR2*VP_A0(Mt,Mu)/(64.*PI2) + gd2*SintR2*CostR2*VP_A0(Mtp,Mu)/(64.*PI2);
    	
    	D8 = -gd2*Mtp2*CostL2*CostR2*B0(MV,Mtp,Mtp,Mu)/(16.*PI2) + gd2*Mtp2*CostL4*B0(MV,Mtp,Mtp,Mu)/(32.*PI2) - gd2*CostL4*B00(MV,Mtp,Mtp,Mu)/(16.*PI2) - gd2*MV2*CostL4*B0(MV,Mtp,Mtp,Mu)/(64.*PI2) + gd2*Mtp2*CostR4*B0(MV,Mtp,Mtp,Mu)/(32.*PI2) - gd2*CostR4*B00(MV,Mtp,Mtp,Mu)/(16.*PI2) - gd2*MV2*CostR4*B0(MV,Mtp,Mtp,Mu)/(64.*PI2) + gd2*CostL4*VP_A0(Mtp,Mu)/(32.*PI2) + gd2*CostR4*VP_A0(Mtp,Mu)/(32.*PI2);
    	
    	D9 = gd4*SinT2*vd2*B00(MV,MV,MH,Mu)/(64.*PI2*MV2) - gd4*SinT2*vd2*B0(MV,MV,MH,Mu)/(64.*PI2);
    	
    	D10 = gd4*CosT2*vd2*B00(MV,MV,MHD,Mu)/(64.*PI2*MV2) - gd4*CosT2*vd2*B0(MV,MV,MHD,Mu)/(64.*PI2);
    	
    	D11 = 3*gd2*MV2*B0(MV,MV,MV,Mu)/(8.*PI2) + 9*gd2*B00(MV,MV,MV,Mu)/(16.*PI2) + gd2*A00(MV,Mu)/(8.*PI2*MV2);
    	
 /*
    	printf("\npiv0D1=%e\n",D1);
    	printf("piv0D2=%e\n",D2);
    	printf("piv0D3=%e\n",D3);
    	printf("piv0D4=%e\n",D4);
    	printf("piv0D5=%e\n",D5);
    	printf("piv0D6=%e\n",D6);
    	printf("piv0D7=%e\n",D7);
    	printf("piv0D8=%e\n",D8);
    	printf("piv0D9=%e\n",D9);
    	printf("piv0D10=%e\n",D10);
    	printf("piv0D11=%e\n",D11);
*/    	
    	
      return D1+D2+D3+3*D4+3*D5+3*D6+3*D7+3*D8+D9+D10+D11;
    
    }
    
 
 /*  
int main(){

	double gd=0.5, MV=5, Mt=172., MtD=172., Mtp=1600.,MHD=1000.;
	double PV0=piv0(gd, MV, Mt, MtD, Mtp, MHD, MV);
	double PVP=pivp(gd, MV, Mt, MtD, Mtp, MHD, MV);
	double MV0=sqrt(pow(MV,2) - PVP + PV0);
	printf("\npiv0=%e\n",piv0(gd, MV, Mt, MtD, Mtp, MHD, MV));
	printf("\nA0(1000, 500)=%e\n",VP_A0(1000., 500.));
	printf("\nA00(1, 1600)=%e\n",A00(1., 1600.));
	printf("\nA00(1, 1000)=%e\n",A00(1., 1000.));
	printf("\nB0(1, 1, 1000, 1)=%e\n",B0(1., 1., 1000., 1.));
	printf("\nB00(1, 1, 200, 1)=%e\n",B00(1., 1., 200., 1.));
	printf("\nDiscB(1, 1, 1000)=%e\n",DiscB(1., 1., 1000.));
	printf("\npivp=%e\n",pivp(gd, MV, Mt, MtD, Mtp, MHD, MV));
	printf("\nMV0=%e\n",MV0);

	return 0;
}    
 */

